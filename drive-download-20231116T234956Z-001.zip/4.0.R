# Project: Datathon 'enhanced code'

# Libraries
packages_to_install <- c("forecast", "ggplot2", "gridExtra", "readr", "kableExtra", "lmtest", "tseries")
install.packages(packages_to_install)

library(forecast)
library(ggplot2)
library(gridExtra)
library(readr)
library(kableExtra)
library(lmtest) # for Durbin-Watson Test
library(tseries) # for Ljung-Box Test

# ... [Your previous code up to the train-test split]

# Enhanced SARIMA Forecasting
sarima_forecast <- function(x, h) {
  fit <- auto.arima(x, seasonal=TRUE, stepwise=FALSE, approximation=FALSE, trace=TRUE)  # Full search
  return(forecast(fit, h = h)$mean)
}
error_sarima <- tsCV(data_ts, sarima_forecast, h = h)
forecast_sarima <- forecast(fit_sarima, h = 36)

# ETS Forecasting
fit_ets <- ets(data_train)
forecast_ets <- forecast(fit_ets, h = 36)

# Ensemble SARIMA and ETS
ensemble_forecast <- (forecast_sarima$mean + forecast_ets$mean) / 2

# Calculate MAPE for Ensemble
mape_ensemble <- mean(100 * abs((data_test - ensemble_forecast) / data_test))
print(paste("Ensemble MAPE on the test set: ", round(mape_ensemble, 2), "%", sep = ""))

# ... [Continue with the rest of your code to visualize residuals and so on]

# Adjusted Performance Table to include Ensemble MAPE
perf_stl_ensemble <- data.frame(rbind(
  cbind('rmse',
        formatC(round(accuracy(forecast_sarima)[ , 'RMSE'], 5), format = 'f', digits = 5),
        formatC(round(sqrt(mean((data_test - ensemble_forecast)^2)), 5), format = 'f', digits = 5),
        formatC(round(sqrt(mean(error^2, na.rm = T)), 5), format = 'f', digits = 5)),
  cbind('mae',
        formatC(round(accuracy(forecast_sarima)[ , 'MAE'], 5), format = 'f', digits = 5),
        formatC(round(mean(abs(data_test - ensemble_forecast)), 5), format = 'f', digits = 5),
        formatC(round(mean(abs(error), na.rm = T), 5), format = 'f', digits = 5)),
  cbind('mape',
        formatC(round(accuracy(forecast_sarima)[ , 'MAPE'], 5), format = 'f', digits = 5),
        formatC(round(mape_ensemble, 5), format = 'f', digits = 5),  # Ensemble MAPE
        formatC(round(cv_mape(error, data_ts), 5), format = 'f', digits = 5))
), stringsAsFactors = F)

# Table Visualization
kable(perf_stl_ensemble, caption = 'Performance - Temperature Anomalies horizon = 12, window = 36', align = 'r', col.names = c('', 'train', 'test', 'cv')) %>%
  kable_styling(full_width = F, position = 'l') %>%
  column_spec(2, width = '7em') %>%
  column_spec(3, width = '4.5em') %>%
  column_spec(4, width = '4.5em')
